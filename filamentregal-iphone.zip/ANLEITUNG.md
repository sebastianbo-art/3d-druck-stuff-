# Filamentregal als iPhone-App

In dieser Anleitung richtest du drei Dinge ein: die App ins Netz stellen, sie auf den Home-Bildschirm legen und den Kurzbefehl für den Foto-Scan bauen. Rechne mit etwa 20 Minuten.

## 1. Deine Daten aus der Claude-Version mitnehmen

1. Öffne das Filamentregal in Claude.
2. Scroll im Tab **Lager** ganz nach unten zu **Daten sichern** und tippe auf **Backup exportieren**. Das Backup liegt jetzt in der Zwischenablage.
3. Füge es in eine Notiz ein, damit es nicht verloren geht.

Die iPhone-Version startet leer, nur mit deinen beiden Druckern. Deine Spulen und Projekte stehen absichtlich nicht in der Datei, weil die Datei öffentlich im Netz liegt.

## 2. App ins Netz stellen (GitHub Pages, kostenlos)

1. Leg ein Konto auf **github.com** an.
2. Tippe auf **New repository**. Name: `filamentregal`, Sichtbarkeit: **Public**. Dann **Create repository**.
3. Tippe auf **uploading an existing file** oder auf **Add file → Upload files**. Wähl alle Dateien aus diesem Ordner aus: `index.html`, `manifest.webmanifest`, `sw.js` und die vier PNG-Bilder. Dann **Commit changes**.
4. Geh zu **Settings → Pages**. Wähl unter *Branch* `main` und `/ (root)` und tippe auf **Save**.
5. Warte ein bis zwei Minuten. Deine App liegt dann unter
   `https://DEIN-NAME.github.io/filamentregal/`

Im Netz liegt nur der Programmcode. Deine Daten bleiben auf dem iPhone.

## 3. Auf den Home-Bildschirm legen

1. Öffne die Adresse in **Safari**.
2. Tippe auf **Teilen → Zum Home-Bildschirm**. Lass „Als Web-App öffnen“ eingeschaltet.
3. Starte die App über das neue Icon.
4. Geh zu **Lager → Daten sichern → Backup importieren**. Kopier vorher das Backup aus deiner Notiz. Tippe dann noch einmal zum Bestätigen.

Ab jetzt funktioniert die App auch offline.

## 4. Kurzbefehl „Filamentregal Scan“ einrichten

Vorher einmal einstellen: **Einstellungen → Apple Intelligence & Siri → ChatGPT** einschalten. Ein ChatGPT-Konto ist nicht nötig, mit Konto hast du aber mehr Anfragen frei. Alternativ wählst du im Kurzbefehl „Private Cloud Compute“, dann läuft alles bei Apple.

Öffne die App **Kurzbefehle**, tippe auf **+** und nenne den Kurzbefehl genau **Filamentregal Scan**. Füge diese Aktionen der Reihe nach hinzu:

1. **Fotos auswählen**. Schalte „Mehrere auswählen“ ein, wenn du mehrere Screenshots auf einmal scannen willst.
2. **Text aus Bild extrahieren**, mit den ausgewählten Fotos als Eingabe.
3. **Text**. Füge den Auftrag unten ein und setze in die letzte Zeile die Variable *Text aus Bild*.
4. **Modell verwenden**. Modell: **ChatGPT** (oder Private Cloud Compute), Anfrage: der *Text* aus Schritt 3. Schalte „Folgefragen“ aus.
5. **In Zwischenablage kopieren**, mit der *Antwort* des Modells.
6. Optional: **Mitteilung anzeigen** mit „Fertig, zurück zur App“.

**Auftrag für Schritt 3:**

```
Du bekommst Text oder ein Foto rund um 3D-Druck-Filament. Das ist entweder ein Spulen-Etikett, Karton, Lieferschein oder eine Rechnung, oder ein Druckprojekt (MakerWorld-Profilseite oder Bambu Studio nach dem Slicen).
Antworte NUR mit JSON, ohne Erklärung und ohne Codeblock.
Bei Etikett, Lieferschein oder Rechnung: {"type":"spulen","items":[{"brand":"Hersteller","product":"Produktlinie, z.B. PLA Basic","material":"PLA, PETG, ABS, ASA, TPU, PA, PC, PETG-CF oder Sonstiges","color":"Farbname wie gedruckt","hex":"#rrggbb, passend zum Farbnamen","net":Nettogewicht in Gramm (Standard 1000),"qty":Anzahl Rollen,"price":Preis pro Rolle in Euro brutto oder null,"refill":true wenn Refill/ohne Spule}]}
Bei einem Druckprojekt: {"type":"projekt","name":"Projektname","plates":[{"name":"Plattenname","minutes":Druckzeit in Minuten (0 wenn unbekannt),"filaments":[{"material":"PLA, PETG, ABS, ASA, TPU, PA, PC oder PETG-CF","color":"Farbname","hex":"#rrggbb","grams":Gramm}]}]}
Gleiche Rollen bzw. gleiche Farben pro Platte zusammenfassen. Versandkosten, Zubehör und Drucker weglassen.

Inhalt:
[Variable: Text aus Bild]
```

Den gleichen Auftrag bekommst du auch in der App über **Scannen → Ohne Kurzbefehl → Auftrag kopieren**.

**So benutzt du ihn:**

1. Tippe in der App auf **Scannen** (Lager) oder unter **+ Projekt** auf **Per Kurzbefehl scannen**.
2. Tippe auf **Kurzbefehl starten** und wähl dein Foto.
3. Wenn der Kurzbefehl fertig ist, geh mit „◀ Filamentregal“ oben links zurück.
4. Tippe auf **Ergebnis einfügen** und erlaube das Einsetzen.
5. Prüf die erkannten Angaben und übernimm sie.

Tipp: Du kannst den Kurzbefehl auch direkt aus Fotos oder nach einem Screenshot über das Teilen-Menü starten. Dafür schaltest du in den Kurzbefehl-Details „Im Share-Sheet anzeigen“ ein.

## Gut zu wissen

- **Updates:** Lad eine neue `index.html` auf GitHub hoch. Die App holt sie beim nächsten Start mit Internet automatisch, deine Daten bleiben dabei erhalten.
- **Sichern:** Exportier ab und zu ein Backup. Wenn du Safari-Daten löschst oder die App vom Home-Bildschirm entfernst, sind die Daten auf dem iPhone weg.
- **3MF-Import:** funktioniert in der iPhone-Version ohne Kurzbefehl und ohne Internet.
